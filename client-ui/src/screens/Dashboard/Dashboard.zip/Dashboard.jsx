import React, { useState } from 'react';
import { FaBars } from 'react-icons/fa'; // Import the menu icon (hamburger icon)
// import { TbCategory } from 'react-icons/tb';
import { FaUsers } from "react-icons/fa";
import { MdProductionQuantityLimits } from "react-icons/md";
import { GiShoppingCart } from "react-icons/gi";
import { ImUsers } from "react-icons/im";




const Dashboard = () => {
  // State to toggle sidebar
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [isDropdown1Open, setisDropdown1Open] = useState(false);
  const [isDropdown2Open, setisDropdown2Open] = useState(false);
  const [isDropdown3Open, setisDropdown3Open] = useState(false);
  const [isDropdown4Open, setisDropdown4Open] = useState(false);

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  return (
    <div className="flex">


      {/* Sidebar */}
      <div
        className={`bg-gray-800 text-white space-y-6 py-7 mb-14 px-2 fixed top-16 left-0 h-[78.9%] z-30 transition-all ${isSidebarOpen ? 'w-64' : 'w-12'
          } mb-4`}
      >
        <div className=" flex justify-between items-center">
          {/* Sidebar Title */}
          <h2 className={`text-xl font-bold text-white ${!isSidebarOpen && 'hidden'}`}>Dashboard</h2>

          {/* Toggle Button */}
          <button
            onClick={toggleSidebar}
            className={`text-white p-2 rounded-md bg-gray-700 hover:bg-gray-600 ${isSidebarOpen ? 'hidden' : 'block'
              } md:block`}
          >
            <FaBars /> {/* Hamburger icon */}
          </button>
        </div>
        
        {/* dashboard options */}
        <nav>
          <ul>
                  {/* settings  */}
            <li className="relative">
              <button onClick={() => setisDropdown1Open(!isDropdown1Open)} className="flex items-center space-x-2 px-4 py-2 rounded-md hover:bg-gray-700" >
                             <FaUsers className={`text-2xl ${!isSidebarOpen && 'hidden'}  `} />
                <span className={`${!isSidebarOpen && 'hidden'}`}>Setting</span>
              </button>
              {/* Dropdown */}
              <div
                className={` left-0 mt-2 w-48 bg-gray-800 text-white rounded-md shadow-lg overflow-hidden transition-all duration ease-in-out ${isDropdown1Open ? 'max-h-60 opacity-100' : 'max-h-0 opacity-0'
                  }`}
              >
                <ul className="flex flex-col">
                  <li className="px-4 py-2 hover:bg-gray-700">View Profile</li>
                  <li className="px-4 py-2 hover:bg-gray-700">Update Profile</li>
                  <li className="px-4 py-2 hover:bg-gray-700">Upload image</li>
                  <li className="px-4 py-2 hover:bg-gray-700">Change password</li>
                  {/* <li className="px-4 py-2 hover:bg-gray-700">Option 5</li> */}
                </ul>
              </div>
            </li>
                {/* Products  */}
            <li className="relative">
              <button
                onClick={() => setisDropdown2Open(!isDropdown2Open)}
                className="flex items-center space-x-2 px-4 py-2 rounded-md hover:bg-gray-700"
              >
                <MdProductionQuantityLimits className={`text-2xl ${!isSidebarOpen && 'hidden'}  `} />

                <span className={`${!isSidebarOpen && 'hidden'}`}>Products</span>
              </button>
              {/* Dropdown */}
              <div
                className={` left-0 mt-2 w-48 bg-gray-800 text-white rounded-md shadow-lg overflow-hidden transition-all duration ease-in-out ${isDropdown2Open ? 'max-h-60 opacity-100' : 'max-h-0 opacity-0'
                  }`}
              >
                <ul className="flex flex-col">
                  <li className="px-4 py-2 hover:bg-gray-700">Add New Product</li>
                  <li className="px-4 py-2 hover:bg-gray-700">View Product</li>
                  {/* <li className="px-4 py-2 hover:bg-gray-700">Upload image</li> */}
                  {/* <li className="px-4 py-2 hover:bg-gray-700">Change password</li> */}
                  {/* <li className="px-4 py-2 hover:bg-gray-700">Option 5</li> */}
                </ul>
              </div>
            </li>
                  {/* Orders  */}
            <li className="relative">
              <button
                onClick={() => setisDropdown3Open(!isDropdown3Open)}
                className="flex items-center space-x-2 px-4 py-2 rounded-md hover:bg-gray-700"
              >
                <GiShoppingCart className={`text-2xl ${!isSidebarOpen && 'hidden'}  `} />

                <span className={`${!isSidebarOpen && 'hidden'}`}>Orders</span>
              </button>
              {/* Dropdown */}
              <div
                className={` left-0 mt-2 w-48 bg-gray-800 text-white rounded-md shadow-lg overflow-hidden transition-all duration ease-in-out ${isDropdown3Open ? 'max-h-60 opacity-100' : 'max-h-0 opacity-0'
                  }`}
              >
                <ul className="flex flex-col">
                  <li className="px-4 py-2 hover:bg-gray-700">View Orders</li>
                  <li className="px-4 py-2 hover:bg-gray-700">Oders History</li>
                  <li className="px-4 py-2 hover:bg-gray-700">Delivered Order</li>
                  {/* <li className="px-4 py-2 hover:bg-gray-700">Payment Proseger</li> */}
                  {/* <li className="px-4 py-2 hover:bg-gray-700">Option 5</li> */}
                </ul>
              </div>
            </li>
                  {/* Users  */}
            <li className="relative">
              <button
                onClick={() => setisDropdown4Open(!isDropdown4Open)}
                className="flex items-center space-x-2 px-4 py-2 rounded-md hover:bg-gray-700"
              >
                <ImUsers className={`text-2xl ${!isSidebarOpen && 'hidden'}  `} />
                <span className={`${!isSidebarOpen && 'hidden'}`}>Users</span>
              </button>
              {/* Dropdown */}
              <div
                className={` left-0 mt-2 w-48 bg-gray-800 text-white rounded-md shadow-lg overflow-hidden transition-all duration ease-in-out ${isDropdown4Open ? 'max-h-60 opacity-100' : 'max-h-0 opacity-0'
                  }`}
              >
                <ul className="flex flex-col">
                  <li className="px-4 py-2 hover:bg-gray-700">View Users</li>
                  {/* <li className="px-4 py-2 hover:bg-gray-700">Update Profile</li> */}
                  {/* <li className="px-4 py-2 hover:bg-gray-700">Upload image</li> */}
                  {/* <li className="px-4 py-2 hover:bg-gray-700">Change password</li> */}
                  {/* <li className="px-4 py-2 hover:bg-gray-700">Option 5</li> */}
                </ul>
              </div>
            </li>

          </ul>
        </nav>
      </div>

      {/* Main Content */}
      <div className={`flex-1 p-6 transition-all ${isSidebarOpen ? 'ml-64' : 'ml-20'}`}>
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl text-gray-400 font-semibold">Welcome to Your Dashboard</h1>
        </div>

        {/* Dashboard Content */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* Card 1 */}
          <div className="bg-gray-800 p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow duration-200">
            <h2 className="text-xl text-white  font-semibold">Sales Overview</h2>
            <p className="text-gray-400  mt-4">View detailed user analytics here.</p>
          </div>
          {/* Card 2 */}
          <div className="bg-gray-800 p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow duration-200">
            <h2 className="text-xl text-white font-semibold">Recent Activity</h2>
            <p className="text-gray-400  mt-4">Monitor the most recent activities on your platform.</p>
          </div>
          {/* Card 3 */}
          <div className="bg-gray-800 p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow duration-200">
            <h2 className="text-xl text-white font-semibold">View Product Details</h2>
            <p className="text-gray-400  mt-4">View system assessories and performance metrics.</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
